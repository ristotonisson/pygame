import pygame
pygame.init

screen=pygame.display.set_mode([300,300])
pygame.display.set_caption("Lumemees-jaanus")
screen.fill([0,0,0])


pygame.draw.rect(screen, [153, 147, 146], [55, 20, 150, 250], 2)
pygame.draw.circle(screen, [255, 0, 0], [130,62], 35, 0)
pygame.draw.circle(screen, [0, 255, 0], [130,145], 35, 0)
pygame.draw.circle(screen, [240, 255, 8], [130,228], 35, 0)










pygame.display.flip()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()