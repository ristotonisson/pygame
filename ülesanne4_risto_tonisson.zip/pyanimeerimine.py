#Risto Tõnisson

import pygame  
import sys  
import random 

pygame.init() 

# Ekraani seaded
screenX = 640 
screenY = 480 
screen = pygame.display.set_mode([screenX, screenY])  # Loo ekraan antud mõõtmetega
pygame.display.set_caption("Animeerimine:Risto")  # Määra akna pealkiri

# Lae taustapilt ja autode pildid
bg = pygame.image.load("bg_rally.jpg")  # Lae taustapilt
auto1 = pygame.image.load("f1_red.png")  # Lae punase auto pilt
auto2 = pygame.image.load("f1_blue.png")  # Lae sinise auto pilt
auto2 = pygame.transform.rotate(auto2, 180)  # Pööra sinist autot 180 kraadi

# Määra autode algpositsioonid ja kiirused
auto1_x, auto1_y = 300, 390  # Punase auto positsioon
speedY = random.randint(1, 15)  # Vertikaalne kiirus sinistele autodele
car_data = [
    {"x": 170, "start_y": random.randint(-screenY, -auto2.get_height())},  # Sinise auto 1 andmed
    {"x": 430, "start_y": random.randint(-screenY, -auto2.get_height())}  # Sinise auto 2 andmed
]

# Mängu muutujad
score = 0  # Algseis on 0 punkti
font = pygame.font.Font(None, 36)  # Fondi seadistus skoori kuvamiseks

clock = pygame.time.Clock()  # Loo kell objekt

game_over = False  # Mängu lõpu indikaator
while not game_over:  # Kuni mäng pole lõppenud
    clock.tick(60)  # Piira kaadrite arvu sekundis 60-ni

    for event in pygame.event.get():  # Käi läbi kõik sündmused
        if event.type == pygame.QUIT:  # Kui sündmus on akna sulgemine
            game_over = True  # Lõpeta mäng

    # Tühjenda ekraan ja joonista taust
    screen.fill((0, 0, 0))  # Täida ekraan mustaga (valikuline)
    screen.blit(bg, [0, 0])  # Joonista taustapilt
    screen.blit(auto1, [auto1_x, auto1_y])  # Joonista punane auto

    # Uuenda ja joonista sinised autod vastavalt car_data'le
    for car in car_data:  # Käi läbi kõik autod
        screen.blit(auto2, [car["x"], car["start_y"]])  # Joonista sinine auto algkoordinaatidel
        car["start_y"] += speedY  # Liiguta sinist autot allapoole

        if car["start_y"] > screenY:  # Kui auto on ekraani alt välja sõitnud
            car["start_y"] = random.randint(-screenY, -auto2.get_height())  # Alusta uuesti ekraani ülaosast
            score += 1  # Suurenda skoori, kui auto läheb ekraani alt välja ja alustab uuesti

    # Joonista skoor ekraanile (vasakus ülanurgas)
    score_text = font.render(f"Score: {score}", True, (255, 255, 255))  # Tekita skoori tekst
    screen.blit(score_text, (10, 10))  # Joonista skoori tekst ekraanile

    pygame.display.flip()  # Uuenda ekraani sisu

pygame.quit()  # Lõpeta pygame
sys.exit()  # Sulge programm