import pygame
pygame.init

pygame.display.set_caption("Ülessane2")
screen = pygame.display.set_mode((640, 480))


bg = pygame.image.load("bg_shop.jpg")

sell = pygame.image.load("seller.png")
sell = pygame.transform.scale(sell, [250, 300])

chat = pygame.image.load("chat.png")

pygame.font.init()

font = pygame.font.Font(pygame.font.match_font("none"), 40)
text = font.render("Risto Tonisson", True, [255,255,255])

text_width = text.get_rect().width
text_height = text.get_rect().height


running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
     
    screen.blit(bg,[0,0])
    screen.blit(sell,[105,160])
    screen.blit(chat,[245,30])
    

    
    text_x = (screen.get_width() - text_width) // 2
    text_y = (screen.get_height() - text_height) // 2
    screen.blit(text, [380-text_width/2,140-text_height/2])



    pygame.display.flip()       
      

pygame.quit()
